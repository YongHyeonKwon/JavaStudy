package Music;

public class MusicClass {


	// 자료형
	
	// 필드
	
	private String path; // 노래 저장 경로

	
	
	// 메소드 (로직, 행위)
	
	//(1) 생성자

	public MusicClass(String path) {
		this.path = path;
	}

	
	//  (2) getter 메소드

	public String getPath() {
		return path;
	}


	
	
	
	

}
